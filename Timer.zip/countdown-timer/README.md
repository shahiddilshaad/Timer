# Countdown Timer

I'll admit, I got a lot of this code from Wes Bos' "JavaScript 30 Challenge" wherein he demonstrates how to make a countdown timer using Vanilla JavaScript.

I'll also acknowledge that one could get a countdown timer any where. So you're probably wondering, "How would this be useful to, anyone?". Well, here's the thing; when I'm using the web in some places I do just look up 'countdown timers', click on the first link (like a normal person), set the timer, and put my headphones on so when the alarm goes off, no one else will be bothered. Thing is, there are times when I need to use my computer and either the web is down, I just can't access the web, or time is of the essence. Obviously, the aforementioned solution wouldn't be feasable. 

### TO DO (Updated 5/25/19):

~~Obviously I've got a stop/reset button, a trigger for the audio aspect of the alarm, and a way to set a custom time.~~

- I'd like to make it so I can set hours, minutes, and seconds. This way, I won't have to find the decimal for the number of seconds I might need. I'll be eliminating those 'preset buttons' to do this, and honestly, I don't think I'll need them any way. 

- Alter the javascript to countdown hours, minutes, and seconds

- Make inputs for the above settings

- ~~Change to CSS so it looks more like something that's my style.~~
